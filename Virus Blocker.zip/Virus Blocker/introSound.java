package org.com;
import java.applet.*;

public class introSound
{
	public static AudioClip getSuara( String prefix, String soundFile ){
		try {
			java.io.File f=new java.io.File(prefix,soundFile);
			return Applet.newAudioClip(f.toURL());
		}
		catch(Exception e) {
			return null;
		}
	}
//
//	public static void main(String bhn[]) {
//		introSound s=new introSound();
//		s.getSuara("sound\\","spacemusic.au").play();
//	}
}
