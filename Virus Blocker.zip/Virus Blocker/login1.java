//package org.com;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class login1 extends JFrame implements ActionListener, MouseListener
{
	JTextField name,pass;

	JButton login=new JButton("Login");
	JButton cancel=new JButton("Cancel");
	JLabel namep=new JLabel("User Name:- ",Label.RIGHT);
	JLabel passp=new JLabel("Password:- ",Label.RIGHT);


	login1()
	{
		setLayout(null);
		name=new JTextField();
		pass=new JPasswordField(15);

		login.setIcon(new ImageIcon("E:\\MANOJ ALL SOFTWERE\\Fonts\\Java Project\\Graphical Data Structure\\Image\\ok1.PNG"));
		name.setSelectionColor(new Color(200,150,150));
		cancel.setIcon(new ImageIcon("E:\\MANOJ ALL SOFTWERE\\Fonts\\Java Project\\Graphical Data Structure\\Image\\cancel1.PNG"));

		name.setForeground(Color.blue);
		pass.setForeground(Color.blue);
		Color clo = new Color(250,50,30);
		namep.setForeground(clo);		passp.setForeground(clo);
		login.setCursor(new Cursor(Cursor.HAND_CURSOR));

		login.setToolTipText("Alt+L");
		cancel.setToolTipText("Alt+C");
		name.setToolTipText("Admin");

		login.setMnemonic(KeyEvent.VK_L);		cancel.setMnemonic(KeyEvent.VK_C);

		namep.setBounds(100,50,250,35);
		name.setBounds(225,50,150,30);
		passp.setBounds(100,100,250,35);
		pass.setBounds(225,100,150,30);


		login.setBounds(100,150,130,40);
		cancel.setBounds(255,150,130,40);

		JLabel user = new JLabel(new ImageIcon("E:\\MANOJ ALL SOFTWERE\\Fonts\\Java Project\\Graphical Data Structure\\Image\\user_48.PNG"));
		JLabel lock = new JLabel(new ImageIcon("E:\\MANOJ ALL SOFTWERE\\Fonts\\Java Project\\Graphical Data Structure\\Image\\key1.PNG"));
		user.setBounds(30,50,80,42);
		lock.setBounds(30,100,80,42);
		getContentPane().add(user,BorderLayout.CENTER);
		getContentPane().add(lock,BorderLayout.CENTER);

		Font lf,tf,bt,pa;
		lf=new Font("Comic Sans MS",Font.PLAIN,20);
		tf=new Font("Bookman Old Style",Font.BOLD,20);
		bt=new Font("Times New Roman",Font.BOLD,17);
		pa=new Font("Lucida Calligraphy",Font.ITALIC,18);

		namep.setFont(lf);
		passp.setFont(lf);
		name.setFont(tf);
		pass.setFont(tf);
		login.setFont(bt);
		cancel.setFont(bt);

		add(namep);
		add(name);
		add(passp);
		add(pass);

		add(login);
		add(cancel);

		setIconImage(new ImageIcon("E:\\MANOJ ALL SOFTWERE\\Fonts\\Java Project\\Graphical Data Structure\\Image\\padlock1.PNG").getImage());
		setLocation(300,200);
		setSize(450,300);
		setVisible(true);
		//setResizable(false);
		setTitle("User Account");
	name.addActionListener(this);
		pass.addActionListener(this);
		login.addActionListener(this);
		cancel.addActionListener(this);
		pass.addActionListener(this);

	}
	public void actionPerformed(ActionEvent ae)
	{

		Object obj=ae.getSource();
		String uname=name.getText();
		String upass=pass.getText();
		if(login==obj)
		 {
			if(uname.equals("Admin") && upass.equals("Admin"))
			{
				JOptionPane.showMessageDialog(this,"Wel-Come To Virsu Blocker System","Wel-Come", JOptionPane.INFORMATION_MESSAGE, new ImageIcon("Image/lock_open_48.png"));
				Scanner d2=new Scanner(1);
				d2.setVisible(true);
				setVisible(false);
			}
			else if (uname.equals("") || upass.equals(""))
			{
				JOptionPane.showMessageDialog(this,"Enter the Correct User Name and Password","ERROR", JOptionPane.ERROR_MESSAGE, new ImageIcon("Image/alert.png"));
			}
			else
			{
				JOptionPane.showMessageDialog(this,"Access Denied","Error", JOptionPane.ERROR_MESSAGE, new ImageIcon("Image/lock_48.png"));
			}
		}
		if(cancel==obj)
		{
				setVisible(false);
		}

	}
	public void mouseClicked(MouseEvent e)
	{
		JOptionPane.showMessageDialog(null,"Hi");
	}
	public void mouseEntered(MouseEvent e)
	{
	}
	public void mouseExited(MouseEvent e)
	{}
	public void mousePressed(MouseEvent e)
	{
	}
	public void mouseReleased(MouseEvent e)
	{
	}
	public static void main(String args[])throws Exception
		{
			new login1();
	}
}
class loginwnd
{

}