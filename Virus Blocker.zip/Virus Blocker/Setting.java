package org.com;

import java.io.*;
import java.util.*;
import javax.swing.*;

public class Setting{
	public Properties  myPanel, myLanguage;
	private String     strNmSetting, strNamaPanel, strLanguage, strLang;

	public Setting(){
	}

	public Setting(String lang){
		strLang = lang;
	}

	public String Language(String language){
		try{
			myLanguage = new Properties();
			myLanguage.load(new FileInputStream("myControl/myLanguage_" + strLang + ".ini"));
			strLanguage = myLanguage.getProperty(language);
		}
		catch(IOException e){
			System.out.print("Error Language : " + e);
		}
		return strLanguage;
	}

	public String SettingPanel(String nmPanel){
		try{
			myPanel = new Properties();
			myPanel.load(new FileInputStream("setting\\database_control.ini"));
			strNamaPanel = myPanel.getProperty(nmPanel);
			//myPanel.clear();
		}
		catch(IOException e){
			JOptionPane.showMessageDialog(null,"Koneksi database tertutup.\nTutup program kemudian jalankan kembali","Alert",
						JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);
		}
		return strNamaPanel;
	}
}