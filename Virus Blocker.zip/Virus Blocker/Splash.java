package org.com;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.LineBorder;

public class Splash extends JWindow{

	private JProgressBar progres=new JProgressBar(0,50);
	private Dimension dim=Toolkit.getDefaultToolkit().getScreenSize();
	private Timer timer;
	JLabel lblimage=new JLabel(new ImageIcon("E:\\MANOJ ALL SOFTWERE\\Fonts\\Java Project\\Graphical Data Structure\\Image\\splash.gif"));
	Color col=new Color(0,0,0);
	int time=0;

	public Splash(){

		lblimage.setBorder(new LineBorder(col,1));

		progres.setValue(0);
		progres.setStringPainted(false);
		progres.setPreferredSize(new Dimension(150,20));

		Container tampung=getContentPane();
		tampung.add(lblimage,BorderLayout.NORTH);
		tampung.add(progres,BorderLayout.CENTER);

		timer=new Timer(100,new ActionListener(){

			public void actionPerformed(ActionEvent aksi){
				time++;
				progres.setValue(time);
				double b=progres.getPercentComplete();
				if(progres.getPercentComplete()==1.0){
					timer.stop();
					setVisible(false);
					new login1();
					introSound s=new introSound();
					s.getSuara("sound","spacemusic.au").play();
					progres.setValue(progres.getMinimum());
				}
			}
		});
		timer.start();

		pack();
		setSize (getSize().width, getSize().height);
		setLocation (dim.width / 2 - getWidth() / 2, dim.height / 2 - getHeight() / 2);
		show();
	}

	public static void main (String args[]) {
		try{
			//UIManager.setLookAndFeel("com.birosoft.liquid.LiquidLookAndFeel");
		}
		catch(Exception e){
			//JOptionPane.showMessageDialog(null,
			//"Look & Feel tidak dapat ditampilkan!","Look & Feel",
			//JOptionPane.ERROR_MESSAGE);
		}
		new Splash ();

	}
}