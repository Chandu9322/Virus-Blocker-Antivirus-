//package org.com;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.ProgressMonitor;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import java.sql.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Login extends JFrame implements ActionListener
{
	static ProgressMonitor pbar;
	static int counter = 0;
	Timer timer;
	public Login()
	{
	    pbar = new ProgressMonitor(null, "Loading Files.......","Initializing . . .", 0, 100);

	    timer = new Timer(70, this);
	    timer.start();
	}
	public void actionPerformed(ActionEvent e)
	{
    	  SwingUtilities.invokeLater(new Update());
   	}
	 class Update implements Runnable
  	{
		public void run()
    	{
			if (pbar.isCanceled())
    	  	{
		     	System.exit(1);
	     		counter=90;
	      	}
      	  	pbar.setProgress(counter);
      		pbar.setNote("Operation is " + counter + "% complete");
      		counter +=1;
      		if(counter==100)
      		{
				System.out.println("Connect To Main Frame");
				pbar.close();
		  		timer.stop();
		  		new login1();
		  	}
    	}
    }
	public static void main(String args[])throws Exception
	{
	   UIManager.put("OptionPane.cancelButtonText", "CANCEL");
	 	Login lo=new Login();
	}
}