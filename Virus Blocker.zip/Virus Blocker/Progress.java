package org.com;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Progress extends JApplet
{
	JProgressBar jprograssbar=new JProgressBar();
	JButton jbutton=new JButton("Increment The Progress Bar");
	public void init()
	{
		Container contentPane=getContentPane();
		contentPane.setLayout(new FlowLayout());
		contentPane.add(jprograssbar);
		contentPane.add(jbutton);
		jprograssbar.setStringPainted(true);
		jbutton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				int i=5;

					jprograssbar.setValue(jprograssbar.getValue()+i);

			}
		});
	}
}